import { Link } from "react-router-dom";
function addrole(){
    return(
     <div className="dashboard">
        <div className="adminadd">
        <h3>add roles</h3>
        <h5>role name</h5>
        <input type="text"></input>
        <Link>add</Link>
        </div>
     </div>
    )
}
export default addrole