import { Link } from "react-router-dom";
function updaterole(){
    return(
        <div className="dashboard">
        <div className="adminadd">
        <h3>update roles</h3>
        <h5>role id</h5>
        <input type="text"></input>
        <h5>role name</h5>
        <input type="text"></input>
        <Link>update</Link>
        </div>
     </div>
    )
}
export default updaterole