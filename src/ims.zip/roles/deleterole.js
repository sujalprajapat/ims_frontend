import { Link } from "react-router-dom";
function deleterole() {
    return (
        <div className="dashboard">
            <div className="adminadd">
                <h3>remove role</h3>
                <h5>role Id</h5>
                <input type="text"></input>
                <Link>delete</Link>
            </div>
        </div>
    )
}
export default deleterole