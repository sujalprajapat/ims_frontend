import Menu from "./dash/menu";
import Dashboard from "./dash/dashboard";
function dashboard(){
    return(
        <div>
                <Menu></Menu>
                <Dashboard/>
        </div>
    )
}
export default dashboard;