import { Link } from "react-router-dom";
function addcourse(){
    return(
     <div className="dashboard">
        <div className="adminadd">
        <h3>add COURSE</h3>
        <h5>COURSE name</h5>
        <input type="text"></input>
        <Link>add</Link>
        </div>
     </div>
    )
}
export default addcourse