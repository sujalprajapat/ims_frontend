import { Link } from "react-router-dom";
function updatecourse(){
    return(
        <div className="dashboard">
        <div className="adminadd">
        <h3>update course</h3>
        <h5>course id</h5>
        <input type="text"></input>
        <h5>role name</h5>
        <input type="text"></input>
        <Link>update</Link>
        </div>
     </div>
    )
}
export default updatecourse