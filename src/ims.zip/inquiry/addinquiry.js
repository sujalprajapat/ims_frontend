import { Link } from "react-router-dom";
function addinquiry() {
    return (
        <div className="dashboard ">
            <div className="inquiry">
                <h3>add inquiry</h3>
                <div className="d-flex justify-content-between flex-wrap ">
                    <div className="text">
                        <h5>branch</h5>
                        <select>
                            <option>select branch</option>
                            <option>select</option>
                            <option>select</option>
                            <option>select</option>
                            <option>select</option>
                        </select>
                    </div>
                    <div className="text">
                        <h5>name</h5>
                        <input type="text"></input>
                    </div>
                    <div className="text">
                        <h5>contact</h5>
                        <input type="text"></input>
                    </div>
                    <div className="text">
                        <h5>course</h5>
                        <select>
                            <option>select course</option>
                            <option>select</option>
                            <option>select</option>
                            <option>select</option>
                            <option>select</option>
                        </select>
                    </div>
                    <div className="text">
                        <h5>extra info</h5>
                        <input type="text"></input>
                    </div>
                    <div className="text">
                        <h5>join date</h5>
                        <input type="date"></input>
                    </div>
                    
                <div className="text">
                        <h5>reference</h5>
                        <select>
                            <option>select ref</option>
                            <option>select</option>
                            <option>select</option>
                            <option>select</option>
                            <option>select</option>
                        </select>
                    </div>
                    <div className="text">
                        <h5>ref. detail</h5>
                        <input type="text"></input>
                    </div>
                    <div className="text">
                        <h5>inquiry by</h5>
                        <select>
                            <option>select role</option>
                            <option>select</option>
                            <option>select</option>
                            <option>select</option>
                            <option>select</option>
                        </select>
                    </div>
                    <div className="text">
                        <h5>status</h5>
                        <select>
                            <option>select status</option>
                            <option>select</option>
                            <option>select</option>
                            <option>select</option>
                            <option>select</option>
                        </select>
                    </div>
                    <div className="text">
                        <h5>status date</h5>
                        <input type="date"></input>
                    </div>
                    <div className="text">
                        <h5>inquiry date</h5>
                        <input type="date"></input>
                    </div>
                </div>
                <div>
                <Link>add</Link>
                </div>
            </div>
        </div>
    )

}
export default addinquiry