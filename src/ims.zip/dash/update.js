import { Link } from "react-router-dom";

function update(){
    return(
        <div className="dashboard">
        <div className="adminadd">
            <h3>update admin</h3>
            <h5>name</h5>
            <input type="text" placeholder=""></input>
            <h5>email</h5>
            <input type="email" placeholder=""></input>
            <h5>password</h5>
            <input type="password" placeholder=""></input>
            <h5>image</h5>
            <input type="file" ></input>
            <h5>role</h5>
            <select>
                <option>select role</option>
                <option>select role</option>
                <option>select role</option>
                <option>select role</option>
                <option>select role</option>
            </select>
            <h5>BRANCH</h5>
            <select>
                <option>select branch</option>
                <option>select branch</option>
                <option>select branch</option>
                <option>select branch</option>
                <option>select branch</option>
            </select>
            <br></br>
            <Link>update</Link>
        </div>
    </div>
    )
}
export default update