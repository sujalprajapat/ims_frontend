import { Link } from "react-router-dom";
function delet(){
    return(
             <div className="dashboard">
                <div className="adminadd">
                <h3>remove addmin</h3>
                <h5>admin Id</h5>
                <input type="text"></input>
                <Link>update</Link>
                </div>
             </div>
    )
}
export default delet