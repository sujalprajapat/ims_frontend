import { Link } from "react-router-dom"

function dashboard(){
    return(
            <div className="dashboard">
                {/* <h1>helllllo</h1> */}
                <div className="d-flex justify-content-between">
                    <div className="dash_box" style={{backgroundColor:"#747AF2"}}>
                        <h2>inquiry : 101</h2>
                        <Link>more info..</Link>
                    </div>
                    <div className="dash_box" style={{backgroundColor:"#EF376E"}}>
                        <h2>branch : 10</h2>
                        <Link>more info..</Link>
                    </div>
                </div>
                <div className="d-flex justify-content-between">
                    <div className="dash_box" style={{backgroundColor:"#FFCC00"}}>
                    <h2>course : 40</h2>
                    <Link>more info..</Link>
                    </div>
                    <div className="dash_box" style={{backgroundColor:"#51CC8A"}}>
                    <h2>role : 20 </h2>
                    <Link>more info..</Link>
                    </div>
                </div>
            </div>
    )
}
export default dashboard
