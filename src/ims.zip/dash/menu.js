import { Container } from 'react-bootstrap';
import { FaBell } from "react-icons/fa";
import { MdOutlineMail } from "react-icons/md";
import { IoMdContact } from "react-icons/io";
import { FaBars } from "react-icons/fa6";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';
function menu() {
    return (
        <div>
            <div className="menu">
                <Container>
                    <div className='d-flex justify-content-between align-items-center '>
                        <div>
                            <h2>IMS</h2>
                        </div>
                        <div className='icon d-flex'>
                            <FaBell></FaBell>
                            <MdOutlineMail></MdOutlineMail>
                            <IoMdContact></IoMdContact>
                            <div className='line'></div>
                            <FaBars></FaBars>
                        </div>
                    </div>

                </Container>
            </div>
            <div className='v_menu'>
                <div className='admin_name d-flex align-items-center'>
                <IoMdContact></IoMdContact>
                 <h3>admin_name</h3>   
                </div>
                <ul className='main_menu'>
                    <hr></hr>
                    <li className='d-flex justify-content-between'><Link to="/dashboard">dashboard</Link></li>     
                    <li><div className='d-flex justify-content-between'><Link to="/admin/add">ADMIN</Link><div className='plus'><Link>+</Link>
                    </div></div>
                    <ul className='submenu'>
                        <li><Link to="/admin/add" >add</Link></li>
                        <li><Link to="/admin/update">update</Link></li>
                        <li><Link to="/admin/delete">remove</Link></li>
                    </ul>     
                    </li>    
                    <li><div className='d-flex justify-content-between'><Link to="/role/add">ROLE</Link><div className='plus'><Link>+</Link></div></div>
                    <ul className='submenu'>
                        <li><Link to="/role/add">add</Link></li>
                        <li><Link to="/role/update">update</Link></li>
                        <li><Link to="/role/delete">remove</Link></li>
                    </ul>     
                    </li> 
                    <li><div className='d-flex justify-content-between'><Link>BRANCH</Link><div className='plus'><Link>+</Link></div></div>
                    <ul className='submenu'>
                        <li><Link to="/branch/add">add</Link></li>
                        <li><Link to="/branch/update">update</Link></li>
                        <li><Link to="/branch/delete">remove</Link></li>
                    </ul>     
                    </li> 
                    <li><div className='d-flex justify-content-between'><Link>COURSE</Link><div className='plus'><Link>+</Link></div></div>
                    <ul className='submenu'>
                        <li><Link to="/course/add">add</Link></li>
                        <li><Link to="/course/update">update</Link></li>
                        <li><Link to="/course/delete">remove</Link></li>
                    </ul>     
                    </li> 
                    <li><div className='d-flex justify-content-between'><Link>REFERENCE</Link><div className='plus'><Link>+</Link></div></div>
                    <ul className='submenu'>
                        <li><Link to="/ref/add">add</Link></li>
                        <li><Link to="/ref/update">update</Link></li>
                        <li><Link to="/ref/delete">remove</Link></li>
                    </ul>     
                    </li> 
                    <li><div className='d-flex justify-content-between'><Link>INQUIRY</Link><div className='plus'><Link>+</Link></div></div>
                    <ul className='submenu'>
                        <li><Link to="/inquiry/add">add</Link></li>
                        <li><Link to="/inquiry/update">update</Link></li>
                        <li><Link to="/inquiry/delete">remove</Link></li>
                    </ul>     
                    </li> 
                    {/* <li><div className='d-flex justify-content-between'><Link>STATUS</Link><div className='plus'><Link>+</Link></div></div>
                    <ul className='submenu'>
                        <li><Link>add</Link></li>
                        <li><Link>update</Link></li>
                        <li><Link>remove</Link></li>
                    </ul>     
                    </li>  */}
                    {/* <li className='d-flex justify-content-between '><Link>ROLE</Link><div className='plus'>+</div></li>         
                    <li className='d-flex justify-content-between '><Link>BRANCH</Link><div className='plus'>+</div></li>         
                    <li className='d-flex justify-content-between '><Link>COURSE</Link><div className='plus'>+</div></li>         
                    <li className='d-flex justify-content-between '><Link>REFERENCE</Link><div className='plus'>+</div></li>         
                    <li className='d-flex justify-content-between '><Link>INQUIRY</Link><div className='plus'>+</div></li>         
                    <li className='d-flex justify-content-between '><Link>STATUS</Link><div className='plus'>+</div></li>          */}
                </ul>
            </div>

        </div>
    )
}
export default menu