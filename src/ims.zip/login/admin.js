import { Link } from "react-router-dom"
function admin()
{
    return(
        <div className="login">
        <div className="adminadd">
        <h3>admin login</h3>
        <h5>email</h5>
        <input type="email"></input>
        <h5>password</h5>
        <input type="password"></input>
        <Link to="/dashboard">login</Link>
        </div>
     </div>
    )
}
export default admin