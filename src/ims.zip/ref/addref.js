import { Link } from "react-router-dom";
function addref(){
    return(
     <div className="dashboard">
        <div className="adminadd">
        <h3>add REFERENCE</h3>
        <h5>REFERENCE name</h5>
        <input type="text"></input>
        <Link>add</Link>
        </div>
     </div>
    )
}
export default addref