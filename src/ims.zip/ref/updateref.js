import { Link } from "react-router-dom";
function updateref(){
    return(
        <div className="dashboard">
        <div className="adminadd">
        <h3>update REFERENCE</h3>
        <h5>REFERENCE id</h5>
        <input type="text"></input>
        <h5>REFERENCE name</h5>
        <input type="text"></input>
        <Link>update</Link>
        </div>
     </div>
    )
}
export default updateref