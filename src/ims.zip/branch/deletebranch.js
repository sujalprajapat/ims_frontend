import { Link } from "react-router-dom";
function deletebranch() {
    return (
        <div className="dashboard">
            <div className="adminadd">
                <h3>remove branch</h3>
                <h5>branch Id</h5>
                <input type="text"></input>
                <Link>delete</Link>
            </div>
        </div>
    )
}
export default deletebranch