import { Link } from "react-router-dom";
function updatebranch(){
    return(
        <div className="dashboard">
        <div className="adminadd">
        <h3>update branch</h3>
        <h5>barnch id</h5>
        <input type="text"></input>
        <h5>branch name</h5>
        <input type="text"></input>
        <Link>update</Link>
        </div>
     </div>
    )
}
export default updatebranch