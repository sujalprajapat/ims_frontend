import { Link } from "react-router-dom";
function addbranch(){
    return(
     <div className="dashboard">
        <div className="adminadd">
        <h3>add branch</h3>
        <h5>branch name</h5>
        <input type="text"></input>
        <h5>address</h5>
        <textarea cols={52} rows={10}></textarea>
        <Link>add</Link>
        </div>
     </div>
    )
}
export default addbranch