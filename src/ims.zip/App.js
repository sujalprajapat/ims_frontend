import logo from './logo.svg';
import './App.css';
import { Route, Routes } from 'react-router-dom';
import Dashboard from './dashboard';
import Menu from './dash/menu';
import Add from './dash/add';
import Updateadmin from './dash/update'; 
import Delet from './dash/delete';
import Addrole from './roles/addrole';
import Updaterole from './roles/updaterole';
import Deleterole from './roles/deleterole';
import Addbranch from './branch/addbranch';
import Deletebranch from './branch/deletebranch';
import Updatebranch from './branch/updatebranch';
import Addcourse from './course/addcourse';
import Deletecourse from './course/deletecourse';
import Updatecourse from './course/updatecourse';
import Addref from './ref/addref';
import Updateref from './ref/updateref';
import Deleteref from './ref/deleteref';
import Addinquiry from './inquiry/addinquiry';
import Deleteinquiry from './inquiry/deleteinquiry';
import Updateinquiry from './inquiry/updateinquiry';
import Admin from './login/admin';
function App() {
  return (
    <div className="App">
      <Routes>
        <Route path='/' element={<Admin/>}></Route> 
        <Route path='/dashboard' element={<Dashboard/>}></Route>
        <Route path='/admin/add' element={<><Add/><Menu/></>}></Route>
        <Route path='/admin/update' element={<><Updateadmin/><Menu/></>}></Route>
        <Route path='/admin/delete' element={<><Delet/><Menu/></>}></Route>
        <Route path='/role/add' element={<><Addrole/><Menu/></>}></Route>
        <Route path='/role/update' element={<><Updaterole/><Menu/></>}></Route>
        <Route path='/role/delete' element={<><Deleterole/><Menu/></>}></Route>
        <Route path='/branch/add' element={<><Addbranch/><Menu/></>}></Route>
        <Route path='/branch/update' element={<><Updatebranch/><Menu/></>}></Route>
        <Route path='/branch/delete' element={<><Deletebranch/><Menu/></>}></Route>
        <Route path='/course/add' element={<><Addcourse/><Menu/></>}></Route>
        <Route path='/course/update' element={<><Updatecourse/><Menu/></>}></Route>
        <Route path='/course/delete' element={<><Deletecourse/><Menu/></>}></Route>
        <Route path='/ref/add' element={<><Addref/><Menu/></>}></Route>
        <Route path='/ref/update' element={<><Updateref/><Menu/></>}></Route>
        <Route path='/ref/delete' element={<><Deleteref/><Menu/></>}></Route>
        <Route path='/inquiry/add' element={<><Addinquiry/><Menu/></>}></Route>
        <Route path='/inquiry/update' element={<><Updateinquiry/><Menu/></>}></Route>
        <Route path='/inquiry/delete' element={<><Deleteinquiry/><Menu/></>}></Route>
      </Routes>
    </div>
  );
}

export default App;
